import sys, os
# Add current directory path in PYTHONPATH
#print sys.path
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
#print sys.path
