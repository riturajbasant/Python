class Realm(object):
    QA = 'QA'
    PROD = 'PROD'

class ApiPath(object):
    DxOpen = 'DxOpen'
    DxlApi = 'DxlApi'